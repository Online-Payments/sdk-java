/*
 * This class was auto-generated.
 */
package com.onlinepayments.domain;

public class EmptyValidator {
}
