/*
 * This class was auto-generated.
 */
package com.onlinepayments.domain;

public class RefundPaymentProduct840SpecificOutput {

	private RefundPaymentProduct840CustomerAccount customerAccount = null;

	public RefundPaymentProduct840CustomerAccount getCustomerAccount() {
		return customerAccount;
	}

	public void setCustomerAccount(RefundPaymentProduct840CustomerAccount value) {
		this.customerAccount = value;
	}

	public RefundPaymentProduct840SpecificOutput withCustomerAccount(RefundPaymentProduct840CustomerAccount value) {
		this.customerAccount = value;
		return this;
	}
}
