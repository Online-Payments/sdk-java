/*
 * This class was auto-generated.
 */
package com.onlinepayments.domain;

public class CompletePaymentCardPaymentMethodSpecificInput {

	private CardWithoutCvv card = null;

	public CardWithoutCvv getCard() {
		return card;
	}

	public void setCard(CardWithoutCvv value) {
		this.card = value;
	}

	public CompletePaymentCardPaymentMethodSpecificInput withCard(CardWithoutCvv value) {
		this.card = value;
		return this;
	}
}
