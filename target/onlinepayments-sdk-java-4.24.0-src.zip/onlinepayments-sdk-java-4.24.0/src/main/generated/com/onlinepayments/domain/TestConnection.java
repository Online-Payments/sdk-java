/*
 * This class was auto-generated.
 */
package com.onlinepayments.domain;

public class TestConnection {

	private String result = null;

	public String getResult() {
		return result;
	}

	public void setResult(String value) {
		this.result = value;
	}

	public TestConnection withResult(String value) {
		this.result = value;
		return this;
	}
}
