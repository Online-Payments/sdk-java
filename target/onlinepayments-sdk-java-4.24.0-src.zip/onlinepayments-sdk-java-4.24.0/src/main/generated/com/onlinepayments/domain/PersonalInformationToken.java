/*
 * This class was auto-generated.
 */
package com.onlinepayments.domain;

public class PersonalInformationToken {

	private PersonalNameToken name = null;

	public PersonalNameToken getName() {
		return name;
	}

	public void setName(PersonalNameToken value) {
		this.name = value;
	}

	public PersonalInformationToken withName(PersonalNameToken value) {
		this.name = value;
		return this;
	}
}
